from django.shortcuts import render
from django.http import HttpResponse

from pages.models import Country_Data
# Create your views here.

def home(request):
    lis = Country_Data.objects.all()
    print (type(lis))
    print("############",lis[0])

    return render(request , 'home.html', {'lis':lis}) 

def map(request):
    return render(request ,'view.html' )

def buildingpage(request):
    return render (request,'building.html')
