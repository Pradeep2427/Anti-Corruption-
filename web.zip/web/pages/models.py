from django.db import models

# Create your models here.


class Country_Data(models.Model):

    rank = models.IntegerField()
    country = models.CharField(max_length = 50)
    corruption_score = models.IntegerField()
    link = models.CharField(max_length= 200)