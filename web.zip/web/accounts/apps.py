from django.apps import AppConfig


class AccoutsConfig(AppConfig):
    name = 'accouts'
